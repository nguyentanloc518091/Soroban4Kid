
var audiotts = document.createElement('audio');

function readtts(sentence , mute){
    if(!mute){
        audiotts.src = 'https://translate.google.com/translate_tts?ie=UTF-8&tl=vi-VN&client=tw-ob&q=' + sentence;
	    audiotts.play();
    }
    
}

function randSoroban(numb){
    var s = 0;
    var numbers = [];
    var rands = [];
    var limit = 9;
    var i  = 0;
    var overi = 0;
    while(true && i < numb && overi < 5000){
        var number = generateRandomInteger(-9, 9);
        if(number != 0){
            if( 0 < s + number && s + number <= limit){
                s += number;
                numbers[i] =  number;
                i++;
            }
        }
        overi++;
    }

    return {
        numbers: numbers,
        s: s
    }
}

function randSoroban22(numb, max){
    var s = 0;
    var numbers = [];
    var rands = [];
    var limit = max;
    var i  = 0;
    var overi = 0;
    while(true && i < numb && overi < 5000){
        var number = generateRandomInteger(-max, max);
        if(number != 0){
            if( 0 < s + number && s + number <= limit){
                s += number;
                numbers[i] =  number;
                i++;
            }
        }
        overi++;
    }

    return {
        numbers: numbers,
        s: s
    }
}

function randSoroban33(numb){
    var s = 0;
    var numbers = [];
    var rands = [];
    var limit = 99;
    var i  = 0;
    var overi = 0;
    while(true && i < numb && overi < 5000){
        var number = generateRandomInteger(-99, 99);
        // var number2 = generateRandomInteger(10,  99);
        // var rand = [number, number2];
        // console.log(rand,generateRandomInteger(0,1),rand[generateRandomInteger(0,1)])
        // number = rand[generateRandomInteger(1,2)];
        var n1ddigit = number%10;
        var n2ddigit = Math.floor((number/10)%10);

        var s1 = s%10;
        var s2 = Math.floor((s/10)%10);


        if(number != 0){
            if((0 <= s1 + n1ddigit && s1 + n1ddigit <= 9) && (0 <= s2 + n2ddigit && s2 + n2ddigit <= 9)){
                s += number;
                numbers[i] =  number;
                i++;
            }
        }
        overi++;
    }

    return {
        numbers: numbers,
        s: s
    }
}

function randSoroban44(numb){
    var s = 0;
    var numbers = [];
    var rands = [];
    var limit = 99;
    var i  = 0;
    var overi = 0;
    while(true && i < numb && overi < 5000){
        var number = generateRandomInteger(-99, 99);
        // var number2 = generateRandomInteger(10,  99);
        // var rand = [number, number2];
        // console.log(rand,generateRandomInteger(0,1),rand[generateRandomInteger(0,1)])
        // number = rand[generateRandomInteger(1,2)];
        var n1ddigit = number%10;
        var n2ddigit = Math.floor((number/10)%10);

        var s1 = s%10;
        var s2 = Math.floor((s/10)%10);


        if(number != 0){
            if((0 <= s + number && s + number <= 99)){
                s += number;
                numbers[i] =  number;
                i++;
            }
        }
        overi++;
    }

    return {
        numbers: numbers,
        s: s
    }
}

function randSoroban222(num){
    var s = 0;
    var numbers = [];
    var rands = [];
    var limit = 9;
    for(var i = 0 ; i < num; i++){
        var rand = (s < limit? s : limit );
        var number = Math.floor(Math.random() * (rand == 0 ? 9 : rand)) + 1;     // returns a random integer from 0 to 9
        if(s + number > limit){
            s -= number;
            rands[i] = rand;
            numbers[i] = (i==0? " " : "-") + number;
        }else{
            s += number;
            rands[i] = rand;
            numbers[i] = (i==0? " " : "+") + number;
        }
        
    }

    return {
        numbers: numbers,
        s: s
    }
    
}

function generateRandomInteger(min, max) {
    return Math.floor(min + Math.random()*(max + 1 - min))
}

function randSoroban2Number(){
    var s = 0;
    var s2 = 0;
    var numbers = [];
    var numbers2 = [];
    var rands = [];
    var limit = 9;
    var i = 0;
    var times = 0;
    while(true && i < 36 && times < 5000){
        var rand = (s < limit? s : limit);
        var number = generateRandomInteger(10, 99) ;     // returns a random integer from 0 to 9

        // console.error(number)
        var n1ddigit = number%10;
        var n2ddigit = Math.floor((number/10)%10);
        if((s + n1ddigit >= limit) && (s2 + n2ddigit >= limit)){
            
            if(n1ddigit - s < 0 || n2ddigit - s2 < 0){

            }else if(s - n1ddigit >= 0 && s2 - n2ddigit >= 0){
                // console.log(number, n2ddigit, n1ddigit);
                s -= n1ddigit;
                s2 -= n2ddigit;
                rands[i] = rand;
                numbers[i] = (i==0? " " : " - ") + number;
                i++;
            }
            
        } else {
            if((s + n1ddigit <= limit) && (s2 + n2ddigit <= limit)){
                s += n1ddigit;
                s2 += n2ddigit;
                rands[i] = rand;
                numbers[i] = (i==0? " " : " + ") + number;
                i++;
            }else if(s - n1ddigit >= 0 && s2 - n2ddigit >= 0){
                // console.log(number, n2ddigit, n1ddigit);
                s -= n1ddigit;
                s2 -= n2ddigit;
                rands[i] = rand;
                numbers[i] = (i==0? " " : " - ") + number;
                i++;
            }
            
        }
        
        times++;
            // if(s + number >= limit && s2 + number2 >= limit){
            //     s -= number;
            //     s2 -= number2;
            //     rands[i] = rand;
            //     numbers[i] = " - " + (number2) + ""+ number;
            //     i++;
            // }else if(s + number < limit && s2 + number2 < limit){
            //     s += number;
            //     s2 += number2;
            //     rands[i] = rand;
            //     numbers[i] = " + " + (number2) + ""+ number;
            //     i++;
            // }  
        
    }
    
    return {
        numbers: numbers,
        s: s,
        s2: s2
    }
}


function randSoroban2Number(num){
    var s = 0;
    var numbers = [];
    var rands = [];
    var limit = 99;
    var times = 0;
    var i = 0 ;
    while(true && i < num && times < 5000){
        var rand = (s < limit? s : limit );
        var number = generateRandomInteger(1, 99) ;     // returns a random integer from 0 to 9
        if(s + number >= limit && s - number >= 0){
            console.error(number)
            s -= number;
            rands[i] = rand;
            numbers[i] = (i==0? " " : " - ") + number;
            i++;
        }else if(s + number <= limit){
            console.error(number)
            s += number;
            rands[i] = rand;
            numbers[i] = (i==0? " " : " + ") + number;
            i++;
        }
        
        
        times++;
    }

    return {
        numbers: numbers,
        s: s
    }
}